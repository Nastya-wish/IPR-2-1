import {Application} from './components/Application';
import './App.css';


function App() {
    return (
        <div className="Application">
            <Application/>
        </div>
    );
}

export default App;
